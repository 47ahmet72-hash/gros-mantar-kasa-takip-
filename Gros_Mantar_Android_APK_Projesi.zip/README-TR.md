# Gros Mantar Kasa Takip — Android APK projesi

Bu proje, yüklediğiniz `index (4).html` dosyasını temel alır. APK, GitHub Actions üzerinden derlenecek şekilde hazırlanmıştır.

## Önemli
- Bu ZIP kaynak projedir; henüz APK dosyası değildir.
- GitHub Actions derleme sırasında ZXing barkod ve SheetJS Excel kütüphanelerini indirip uygulamanın içine koyar. APK kurulduktan sonra bu iki özellik internet olmadan da kullanılabilir.
- Kasa/personel kayıtları cihazdaki WebView yerel depolamasında tutulur. Telefon verilerini temizlemek veya uygulamayı kaldırmak kayıtları silebilir; düzenli JSON yedeği alın.
- Bulut senkronizasyonu ayarları mevcut HTML dosyasından korunmuştur; bulut işlemleri internet ister. Yerel kayıt ve USB klavye tipi barkod okuyucu internet olmadan çalışabilir.
- USB barkod okuyucu, Android'e klavye gibi bağlanıyorsa barkod alanına odaklanıp okutun; okuyucunun Enter son eki göndermesi gerekir.
- Kamera izni ilk kamera kullanımında Android tarafından istenir.

## APK üretme — telefondan
1. ZIP'i telefonunuza indirin ve arşivden çıkarın.
2. GitHub'da yeni bir depo açın veya mevcut deponuzun içine bu projenin dosyalarını ekleyin. Proje dosyalarını depo kök dizinine koyun; `.github` klasörünü de yükleyin.
3. GitHub deposunda **Actions** sekmesini açın. Gerekirse “I understand my workflows, go ahead and enable them” seçeneğini etkinleştirin.
4. **Gros Mantar APK oluştur** iş akışını seçip **Run workflow** düğmesine basın. `push` ile de otomatik derleme başlar.
5. İş bitince aynı iş akışının tamamlanan çalışmasına girin. Sayfanın altındaki **Artifacts** bölümünden `Gros-Mantar-Kasa-Takip-APK` dosyasını indirin.
6. İnen ZIP'i açın, içindeki `app-debug.apk` dosyasına dokunun ve Android kurulum ekranını izleyin. Android “bilinmeyen uygulama yükleme” izni isterse yalnızca kullandığınız tarayıcı/dosya yöneticisi için izin verin.

## Yapı
- `app/src/main/assets/www/index.html`: mevcut kasa takip uygulaması
- `app/src/main/java/.../MainActivity.kt`: WebView kabuğu, kamera izni
- `.github/workflows/build-apk.yml`: GitHub üzerinde APK derleme

İlk kurulumdan önce mevcut web uygulamanızdaki kayıtları JSON yedek olarak dışa aktarmanız önerilir. APK, web sitesindeki tarayıcı depolamasını otomatik olarak içe aktarmaz.
